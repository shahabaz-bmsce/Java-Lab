/*Write a program in Java which creates two threads, one thread displaying “BMS College 
of Engineering” once every ten seconds and another displaying “CSE” once every two 
seconds.*/
class Thread1 extends Thread { 
    public void run () {  
            try { 
                for (int i = 0; i < 5; i++) { 
                    System.out.println("BMSCE"); 
                    Thread.sleep(10000); 
                } 
            } catch (InterruptedException e) { 
                System.out.println("BMSCE IE"); 
            } 
        } 
    } 

 
class Thread2 extends Thread { 
    public void run () { 
            try { 
                for (int i = 0; i < 5; i++) { 
                    System.out.println("CSE"); 
                    Thread.sleep(2000); 
                } 
            } catch (InterruptedException e) { 
                System.out.println("CSE IE"); 
            } 
        } 
    } 

 
public class ThreadProgram { 
    public static void main(String[] args) { 
        Thread1 t1 = new Thread1(); 
        Thread2 t2 = new Thread2(); 
        t1.start(); t2.start(); 
    } 
} 