/*Write a program in Java to create a class Book which contains four members: name, author, 
price, num_pages. Include a constructor to set the values for the members. Include methods to 
set and get the details of the objects. Include a toString () method that could display the 
complete details of the book. Develop a Java program to create n book objects. 
import java.util.Scanner;*/
 
import java.util.Scanner;

class Book {
    String name;
    String author;
    double price;
    int num_pages;

    Book(String name, String author, double price, int num_pages) {
        this.name = name;
        this.author = author;
        this.price = price;
        this.num_pages = num_pages;
    }

    void setDetails() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Book Name: ");
        this.name = sc.nextLine();
        System.out.print("Enter Author Name: ");
        this.author = sc.nextLine();
        System.out.print("Enter Book Price: ");
        this.price = sc.nextDouble();
        System.out.print("Enter number of pages: ");
        this.num_pages = sc.nextInt();
    }

    void getDetails() {
        System.out.println("Book Name: " + name);
        System.out.println("Book Author: " + author);
        System.out.println("Book Price: " + price);
        System.out.println("Number of Pages: " + num_pages);
    }

    public String toString() {
        return "Book Details:\n" +
               "Name: " + name +
               "\nAuthor: " + author +
               "\nPrice: Rs " + price +
               "\nNumber of pages: " + num_pages;
    }
}

public class BooksWithNumberobjects {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of books: ");
        int n = sc.nextInt();

        Book[] b = new Book[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter Details for Book " + (i + 1));
            b[i] = new Book("", "", 0.0, 0);
            b[i].setDetails();
        }

        System.out.println("\nComplete Details of all Books");
        for (int i = 0; i < n; i++) {
            System.out.println("\nBook " + (i + 1));
            System.out.println(b[i]);
        }
    }
}
