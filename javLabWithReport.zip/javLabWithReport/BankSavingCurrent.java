/*Write a program in Java to create a class Bank that maintains two kinds of account for its 
customers, one called savings account and the other current account. The savings account 
provides interest but no withdrawal facilities. The current account provides withdrawal facility 
but no interest. Current account holders should also maintain a minimum balance and if the 
balance falls below this level, a penalty is imposed. Create a class Account that stores customer 
name, account number. From this derive the classes Cur-acct and Sav-acct to make them more 
specific to their requirements. Include the necessary methods in order to achieve the following 
tasks:  
a) Accept deposit from customer and update the balance.  
b) Display the balance. 
c) Compute and deposit interest. 
d) Permit withdrawal and update the balance Check for the minimum balance, impose 
penalty if necessary and update the balance.*/
import java.util.Scanner; 
 
class Account { 
    String customerName; 
    String accountNumber; 
    double balance; 
 
    Account (String customerName, String accountNumber) { 
        this.customerName = customerName; 
        this.accountNumber = accountNumber; 
    } 
 
    void deposit (double amount) { 
        balance += amount; 
        System.out.println("Deposit of Rs" + amount + " successful."); 
    } 
 
    void displayBalance () { 
        System.out.println("Account Number: " + accountNumber + "\nBalance: " + balance); 
    } 
} 
 
class SavingsAccount extends Account { 
    SavingsAccount (String customerName, String accountNumber) { 
        super(customerName, accountNumber); 
    } 
    void addInterest (double years) {
           double interestRate = 5; 
        if (years <= 0) { 
            System.out.println("No time passed, no interest added."); 
        } 
        double r = interestRate / 100.0; 
        balance += balance * r * years; 
    } 
} 
 
class CurrentAccount extends Account { 
    double minimumBalance = 1000; 
 
    CurrentAccount (String customerName, String accountNumber) { 
        super(customerName, accountNumber); 
    } 
 
    void withdraw (double amount) { 
        if (balance >= amount) { 
            balance -= amount; 
            System.out.println("Withdrawal of Rs" + amount + " successful."); 
                if (balance < minimumBalance) { 
                    imposePenalty(); 
                } 
        } 
        else { 
            System.out.println("Insufficient funds."); 
        } 
    } 
 
    void imposePenalty () { 
        double penalty = 200; 
        balance -= penalty; 
        System.out.println("Penalty of Rs" + penalty + " imposed."); 
    } 
} 
 
public class BankSavingCurrent { 
    public static void main(String[] args) { 
        Scanner sc = new Scanner (System.in); 
        System.out.println("1. Savings Account \n2. Current Account"); 
        System.out.print("Enter choice: "); 
        int choice = sc.nextInt(); 
        Account acc; 
        if (choice == 1) {
            acc = new SavingsAccount("Alice","1234"); 
        } 
        else { 
            acc = new CurrentAccount("James", "5678"); 
        } 
        while (true) { 
            System.out.println("\n|Menu|"); 
            System.out.println("1. Deposit"); 
            System.out.println("2. Withdraw"); 
            System.out.println("3. Display Balance"); 
            System.out.println("4. Compute Interest (Savings Account only)"); 
            System.out.println("5. Exit"); 
            System.out.print("Enter your choice: "); 
            int choice2 = sc.nextInt(); 
            switch (choice2) { 
            case 1: 
                System.out.print("Enter amount to deposit: "); 
                double amount = sc.nextDouble(); 
                acc.deposit(amount); 
                break; 
            case 2: 
                if (acc instanceof SavingsAccount) 
                    System.out.println("Withdrawal not allowed for Savings Account."); 
                else { 
                    System.out.print("Enter amount to withdraw: "); 
                    amount = sc.nextDouble(); 
                    ((CurrentAccount) acc).withdraw(amount); 
                    break; 
                } 
            case 3: 
                acc.displayBalance(); 
                break; 
            case 4: 
                if (acc instanceof SavingsAccount) 
                    ((SavingsAccount) acc).addInterest(2); 
                else { 
                    System.out.print("Interest computation not applicable for Current Account."); 
                } 
                break; 
            case 5: 
                System.exit(0); 
                break; 
            default: System.out.println("Invalid Choice."); 
            }
         } 
    } 
} 