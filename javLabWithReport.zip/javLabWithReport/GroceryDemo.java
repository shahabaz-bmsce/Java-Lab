/* Write a program in Java to create a class Grocery with members quantities of any three 
items. Write a constructor to initialize the members. Include methods to calculate total 
bill price for the three items and display it in the main function. */

class Grocery { 
    double quantityDal, quantitySugar, quantityPulses; 
 
    Grocery (double qd, double qs, double qp) { 
        quantityDal = qd; 
        quantitySugar = qs; 
        quantityPulses = qp; 
    } 
 
    double bill () { 
        double totalBill = (140 * quantityDal) + (60 * quantitySugar) + (90 * quantityPulses); 
        return totalBill; 
    } 
} 
 
class GroceryDemo { 
    public static void main(String[] args) { 
        Grocery G1 = new Grocery(7, 4, 6); 
        Grocery G2 = new Grocery(13, 15, 14); 
        System.out.println("Total Bill Amount for G1: " + G1.bill()); 
        System.out.println("Total Bill Amount for G2: " + G2.bill()); 
    } 
} 