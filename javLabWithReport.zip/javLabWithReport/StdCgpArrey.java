import java.util.Scanner; 
 
class Student { 
    String usn, name; 
    int [] credits, marks; 
     /*write a program in Java to create a class Student with members USN, name, an array 
credits and an array mark. Include methods to accept and display details and a method 
to calculate SGPA of a student. */
 
    void acceptDetails(Scanner sc) { 
        System.out.print("Enter USN: "); 
        usn = sc.nextLine(); 
        System.out.print("Enter Name: "); 
        name = sc.nextLine(); 
        credits = new int [4]; 
        marks = new int [4]; 
        System.out.println("Enter details of credits and marks in order for 4 subjects"); 
        for (int i = 0; i < 4; i++) { 
            System.out.print("Enter credits for Subject " + (i+1) + ": "); 
            credits[i] = sc.nextInt(); 
            System.out.print("Enter marks for Subject " + (i+1) + ": "); 
            marks[i] = sc.nextInt(); 
        } 
        sc.nextLine(); 
    } 
 
    void display () { 
        System.out.println("\nStudent Details"); 
        System.out.println("USN: " + usn); 
        System.out.println("Name: " + name); 
        for (int i = 0; i < 4; i++) { 
            System.out.println("Subject " + (i+1) + " - Credits: " + credits[i] + ", Marks: " + 
marks[i]); 
        } 
    } 
 
    double calculateSgpa () { 
        int totalCredits = 0; 
        double totalGp = 0; 
        for (int i = 0; i < 4; i++) { 
            totalCredits += credits[i]; 
            totalGp += gradePoint(marks[i]) * credits[i];
             } 
        return totalGp / totalCredits; 
    } 
 
    int gradePoint (int marks) { 
        if (marks >= 90) return 10; 
        else if (marks >= 80) return 9; 
        else if (marks >= 70) return 8; 
        else if (marks >= 60) return 7; 
        else if (marks >= 50) return 6; 
        else if (marks >= 40) return 5; 
        else return 0; 
    } 
} 
 
class StdCgpArrey{ 
    public static void main(String[] args) { 
        Scanner sc = new Scanner (System.in); 
        System.out.print("Enter number of students: "); 
        int numberOfStudents = sc.nextInt(); 
        sc.nextLine(); 
        Student student [] = new Student [numberOfStudents]; 
        for (int i = 0; i < numberOfStudents; i++) { 
            student[i] = new Student(); 
            student[i].acceptDetails(sc); 
            student[i].display(); 
            System.out.printf("SGPA: %.2f%n", student[i].calculateSgpa()); 
        } 
        sc.close(); 
    } 
} 
