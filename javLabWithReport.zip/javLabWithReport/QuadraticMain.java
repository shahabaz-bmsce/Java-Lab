import java.util.Scanner; 
 
class Quadratic { 
    double a, b, c, d; 
 
    void input () { 
        Scanner sc = new Scanner (System.in); 
        System.out.print("Enter the coefficients (a, b, c): "); 
        a = sc.nextDouble(); 
        b = sc.nextDouble(); 
        c = sc.nextDouble(); 
        sc.close(); 
    } 
 
    void calculateRoots () { 
        double r1, r2; 
        d = (b * b) - (4 * a * c); 
        if (d == 0) { 
            r1 = r2 = (-b) / (2 * a); 
            System.out.println("Roots are Real and Equal."); 
        } else if (d > 0) { 
            r1 = (-b + (Math.sqrt(d)) / (2 * a)); 
            r2 = (-b - (Math.sqrt(d)) / (2 * a)); 
            System.out.println("Roots are Real and Distinct."); 
        } else { 
            r1 = (-b) / (2 * a); 
            r2 = Math.sqrt(-d) / (2 * a); 
            System.out.println("Roots are Imaginary."); 
        } 
        System.out.println("R1 = " + r1); 
        System.out.println("R2 = " + r2); 
    } 
} 
 
class QuadraticMain { 
    public static void main(String[] args) { 
        Quadratic Q1 = new Quadratic(); 
        Q1.input(); 
        Q1.calculateRoots(); 
    } 
} 