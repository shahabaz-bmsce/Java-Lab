// Custom Exception 1
class NegativeAgeException extends Exception {
    NegativeAgeException(String msg) {
        super(msg);
    }
}

// Custom Exception 2
class UnderAgeException extends Exception {
    UnderAgeException(String msg) {
        super(msg);
    }
}

// Custom Exception 3
class OverAgeException extends Exception {
    OverAgeException(String msg) {
        super(msg);
    }
}

// Class that checks age
class AgeCheck {

    void checkAge(int age)
            throws NegativeAgeException, UnderAgeException, OverAgeException {

        if (age < 0) {
            throw new NegativeAgeException("Age cannot be negative");
        }
        else if (age < 18) {
            throw new UnderAgeException("Age below 18 not allowed");
        }
        else if (age > 60) {
            throw new OverAgeException("Age above 60 not allowed");
        }

        System.out.println("Age accepted: " + age);
    }
}

// Main class
public class MultipleException {
    public static void main(String[] args) {

        AgeCheck ac = new AgeCheck();

        try {
            ac.checkAge(65);   // change value to test
        }
        catch (NegativeAgeException e) {
            System.out.println(e.getMessage());
        }
        catch (UnderAgeException e) {
            System.out.println(e.getMessage());
        }
        catch (OverAgeException e) {
            System.out.println(e.getMessage());
        }
    }
}
