class AreaCal {

    // Area of Circle
    void area(double r) {
        System.out.println("Area of Circle = " + (3.14 * r * r));
    }

    // Area of Square
    void area(int side) {
        System.out.println("Area of Square = " + (side * side));
    }

    // Area of Rectangle
    void area(int l, int b) {
        System.out.println("Area of Rectangle = " + (l * b));
    }

    // Area of Triangle
    void area(double b, double h) {
        System.out.println("Area of Triangle = " + (0.5 * b * h));
    }
}

public class methodOverloading {
    public static void main(String[] args) {

        AreaCal a = new AreaCal();

        a.area(5.0);        // Circle
        a.area(4);          // Square
        a.area(6, 3);       // Rectangle
        a.area(8.0, 4.0);   // Triangle
    }
}
