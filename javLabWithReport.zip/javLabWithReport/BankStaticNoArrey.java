/*Write a program in Java to create a simple banking system for a small bank. Each bank 
customer has an account with a unique account number, name, and balance. The bank 
also wants to keep track of: 
1. How many total accounts have been created. 
2. The interest rate (same for all accounts). 
3. Methods to withdraw, deposit and compute simple interest on a given account. 
*/
class BankAccount { 
    String accountNo, custName; 
    double balance; 
    static int accountCount = 0; 
    static double interestRate; 
 
    static { 
        interestRate = 4.5; 
        System.out.println("Static block: Initial interest Rate set to " + 
        interestRate + "%"); 
    } 
 
    BankAccount (String accountNo, String custName, double initialBalance) { 
        this.accountNo = accountNo; 
        this.custName = custName; 
        this.balance = initialBalance; 
        accountCount++; 
    } 
 
    void deposit (double amount) { 
        if (amount > 0) 
            balance += amount; 
        else 
            System.out.println("Cannot deposit non-positive amount: " + amount); 
    } 
 
    void withdraw (double amount) { 
        if (amount <= 0) 
            System.out.println("Cannot withdraw non-positive amount: " +amount); 
        else if (amount > balance) 
            System.out.println("Insufficient Balance. Requested: " + amount +", Available: " + 
balance); 
        else 
            balance -= amount; 
    } 
 
    void addInterest (double years) {
                if (years <= 0) 
            System.out.println("No time passed, no interest added."); 
            double r = interestRate / 100.0; 
            balance += balance * r * years; 
        } 
 
    static void changeInterestRate (double newRate) { 
            if (newRate < 0) 
                System.out.println("Interest Rate cannot be negative: " + newRate); 
            else 
                interestRate = newRate; 
    } 
 
    static int getAccountCount() { 
            return accountCount; 
    } 
 
    static double getInterestRate() { 
            return interestRate; 
    } 
 
    void displayDetails () { 
        System.out.println("\nAccount Number: " + accountNo + "\nCustomer Name: " + 
custName + "\nBalance: " + String.format("%.2f", balance)); 
    } 
} 
 
class BankStaticNoArrey { 
    public static void main(String[] args) { 
        System.out.println("Creating Bank Accounts..."); 
        BankAccount acc1 = new BankAccount("ACC1001", "Ram", 1000.0); 
        BankAccount acc2 = new BankAccount("ACC1002", "Sita", 2000.0); 
        BankAccount acc3 = new BankAccount("ACC1003", "Laxman", 1500.0); 
        System.out.println("\nNumber of accounts created: " + 
        BankAccount.getAccountCount()); 
        System.out.println("Initial Account Details\n"); 
        acc1.displayDetails(); 
        acc2.displayDetails(); 
        acc3.displayDetails(); 
        System.out.println("\nAdding interest based on interest rate = " + 
        BankAccount.getInterestRate() + "%"); 
        acc1.addInterest(0.5); 
        acc2.addInterest(1.0); 
        acc3.addInterest(1.5); 
        System.out.println("\nBalances after interest: "); 
        acc1.displayDetails(); 
        acc2.displayDetails(); 
        acc3.displayDetails(); 
        System.out.println("\nChanging interest rate to 5.5%"); 
        BankAccount.changeInterestRate(5.5); 
        System.out.println("New interest rate: " + 
        BankAccount.getInterestRate() + "%"); 
        System.out.println("Adding interest again with new rate: "); 
        acc1.addInterest(0.5); 
        acc2.addInterest(1.0); 
        acc3.addInterest(1.5); 
        System.out.println("\nFinal Balances: "); 
        acc1.displayDetails(); 
        acc2.displayDetails(); 
        acc3.displayDetails(); 
    } 
} 