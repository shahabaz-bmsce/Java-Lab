/*Write a program in Java to create an abstract class named Shape that contains two 
integers and an empty method named printArea (). Provide three classes named 
Rectangle, Triangle and Circle such that each one of the classes extends the class Shape. 
Each one of the classes contain only the method printArea () that prints the area of the 
given shape.*/
import java.util.Scanner; 
 
abstract class Shape { 
    double a, b; 
 
    abstract void printArea(); 
} 
class Rectangle extends Shape { 
    void printArea () { 
        System.out.println("Area of Rectangle is: " + (a*b) + "\n"); 
    } 
} 
class Circle extends Shape { 
    void printArea () { 
        System.out.println("Area of Circle is: " + (3.14*a*a) + "\n"); 
    } 
} 
class Triangle extends Shape { 
    void printArea () { 
        System.out.println("Area of Triangle is: " + (0.5*a*b) + "\n"); 
    } 
} 
public class AbstractedShapeWithCase { 
    public static void main(String[] args) { 
        int n; 
        Rectangle r = new Rectangle(); 
        Triangle t = new Triangle(); 
        Circle c = new Circle(); 
        Scanner sc = new Scanner(System.in); 
        while(true) { 
            System.out.println("Main Menu\n1.Rectangle\n2.Triangle\n3.Circle\n4.Exit"); 
            System.out.print("\nEnter Choice: "); 
            n = sc.nextInt(); 
            switch (n) { 
                case 1: System.out.print("Enter length: "); 
                        r.a = sc.nextDouble(); 
                         sc.nextLine(); 
                        System.out.print("Enter breadth: "); 
                        r.b = sc.nextDouble(); 
                        sc.nextLine(); 
                        r.printArea(); 
                        break; 
                case 2: System.out.print("Enter length: "); 
                        t.a = sc.nextDouble(); 
                        sc.nextLine(); 
                        System.out.print("Enter height: "); 
                        t.b = sc.nextDouble(); 
                        sc.nextLine(); 
                        t.printArea(); 
                        break; 
                case 3: System.out.print("Enter radius: "); 
                        c.a = sc.nextDouble(); 
                        sc.nextLine(); 
                        c.printArea(); 
                        break; 
                case 4: System.out.print("Exiting...\n"); 
                        System.exit(0); 
                        break; 
                default: System.out.println("Invalid input.\n"); 
            } 
        } 
    } 
}
