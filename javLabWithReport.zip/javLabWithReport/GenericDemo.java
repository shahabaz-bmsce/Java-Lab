// Generic class with two type parameters
class Gen<T, U> {
    T first;
    U second;

    // Constructor
    Gen(T first, U second) {
        this.first = first;
        this.second = second;
    }

    // Display method
    void display() {
        System.out.println("First Value : " + first);
        System.out.println("Second Value: " + second);
    }
}

public class GenericDemo {
    public static void main(String[] args) {

        // Object 1: Integer + String
        Gen<Integer, String> obj1 =
                new Gen<>(101, "Java");
        obj1.display();

        System.out.println();

        // Object 2: Double + String
        Gen<Double, String> obj2 =
                new Gen<>(99.5, "Marks");
        obj2.display();
    }
}
