class Box { 
    double length, width, height; 
 
    Box (double length, double width, double height) { 
        this.length = length; 
        this.width = width; 
        this.height = height; 
    } 
 
    double calculateVolume () { 
        double volume = length * width * height; 
        return volume; 
    } 
} 
 
class BoxDemo { 
    public static void main(String[] args) { 
        Box B1 = new Box (5, 5, 5); 
        Box B2 = new Box (10.1, 10.2, 10.3); 
        System.out.println("Volume of B1: " + B1.calculateVolume()); 
        System.out.println("Volume of B2: " + B2.calculateVolume()); 
    } 
} 