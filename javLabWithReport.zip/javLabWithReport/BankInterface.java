/*Write a program in Java to implement a Bank interface. Write two bank classes that 
implements this interface with each having different members of retrieving data from the 
user. Write a main function to demonstrate the working of the interface by asking the 
user for choice of bank and dynamically invoking the respective object. 
*/
import java.util.Scanner; 
 
interface FixedDeposit { 
    void getDetails(); 
    void showDetails(); 
    void calcInterest(); 
} 
 
class HDFCBank implements FixedDeposit { 
    String Name, pan; 
    int age; 
    double principle, time; 
    public void getDetails() { 
        Scanner sc = new Scanner (System.in); 
        System.out.print("Enter Name: "); 
        Name = sc.nextLine(); 
        System.out.print("Enter PAN: "); 
        pan = sc.nextLine(); 
        System.out.print("Enter age: "); 
        age = sc.nextInt(); 
        sc.nextLine(); 
        System.out.print("Enter principle: "); 
        principle = sc.nextDouble(); 
        sc.nextLine(); 
        System.out.print("Enter time: "); 
        time = sc.nextDouble(); 
        sc.nextLine(); 
        sc.close(); 
    } 
 
    public void showDetails() { 
        System.out.println("\nDetails"); 
        System.out.println("Name: " + Name); 
        System.out.println("PAN: " + pan); 
        System.out.println("Age: " + age);
         } 
 
    public void calcInterest() { 
        double rate = 4.0; 
        double interest = (principle * rate * time) / 100.0; 
        System.out.println("Interest at rate " + rate + "% is: " + interest); 
    } 
} 
 
class IndianBank implements FixedDeposit { 
    String Name, aadhaar, phoneno; 
    double principle, time; 
    public void getDetails() { 
        Scanner sc = new Scanner (System.in); 
        System.out.print("Enter Name: "); 
        Name = sc.nextLine(); 
        System.out.print("Enter Aadhaar: "); 
        aadhaar = sc.nextLine(); 
        System.out.print("Enter Phone Number: "); 
        phoneno = sc.nextLine(); 
        System.out.print("Enter principle: "); 
        principle = sc.nextDouble(); 
        sc.nextLine(); 
        System.out.print("Enter time: "); 
        time = sc.nextDouble(); 
        sc.nextLine(); 
        sc.close(); 
    } 
 
    public void showDetails() { 
        System.out.println("\nDetails"); 
        System.out.println("Name: " + Name); 
        System.out.println("Aadhaar: " + aadhaar); 
        System.out.println("Phone Number: " + phoneno); 
    } 
 
    public void calcInterest() { 
        double rate = 4.5; 
        int years = (int) time; 
        double interest = ((principle * rate * time) / 100.0) + (300 * years); 
        System.out.println("Interest at rate " + rate + "% is: " + interest); 
    } 
} 
class BankInterface {
    public static void main(String[] args) { 
        Scanner sc = new Scanner (System.in); 
        System.out.println("Banking System\n1.HDFC Bank\n2.Indian Bank"); 
        System.out.print("Enter choice: "); 
        int choice = sc.nextInt(); 
        sc.nextLine(); 
        FixedDeposit fd; 
        if (choice == 1) 
            fd = new HDFCBank(); 
        else if (choice == 2)  
            fd = new IndianBank(); 
        else { 
            System.out.println("Invalid Choice!\n"); 
            return; 
        } 
        fd.getDetails(); 
        fd.showDetails(); 
        fd.calcInterest(); 
        sc.close(); 
    } 
}
